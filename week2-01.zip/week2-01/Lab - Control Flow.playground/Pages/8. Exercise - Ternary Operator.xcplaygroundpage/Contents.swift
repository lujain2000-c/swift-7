/*:
## Exercise - Ternary Operator
 
 Refactor the code below so that `largest` is declared and assigned to in one line using the ternary operator.
 */
let number1 = 14
let number2 = 25

var largest: Int
if number1 > number2 {
    largest = number1
} else {
    largest = number2
}

//number1 > number2 ? largest = number1 : largest = number2

number1 > number2 ? print("number1 is the largest") : print("number2 is the largest")
/*:
[Previous](@previous)  |  page 8 of 9  |  [Next: App Exercise - Ternary Messages](@next)
 */
